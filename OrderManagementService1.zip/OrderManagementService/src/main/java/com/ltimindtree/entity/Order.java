package com.ltimindtree.entity;

import java.time.LocalDateTime;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="orders")
public class Order {
	
	
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private Long id;
	private Long customerId;
	private String status;
	private Long restaurantId;
	
	@CreationTimestamp
    private LocalDateTime createDateTime;
    @UpdateTimestamp
    private LocalDateTime updateDateTime;
	
	/*
	 * //@OneToMany(mappedBy = "orders", cascade = CascadeType.ALL,fetch =
	 * FetchType.EAGER)
	 * 
	 * @OneToMany(targetEntity = ItemDetails.class,cascade = CascadeType.ALL,fetch =
	 * FetchType.EAGER)
	 * 
	 * @JoinColumn(name="id_fk")
	 */
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private ItemDetails itemDetail;

	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Order(Long id, Long customerId, String status, Long restaurantId, LocalDateTime createDateTime,
			LocalDateTime updateDateTime, ItemDetails itemDetail) {
		super();
		this.id = id;
		this.customerId = customerId;
		this.status = status;
		this.restaurantId = restaurantId;
		this.createDateTime = createDateTime;
		this.updateDateTime = updateDateTime;
		this.itemDetail = itemDetail;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getRestaurantId() {
		return restaurantId;
	}

	public void setRestaurantId(Long restaurantId) {
		this.restaurantId = restaurantId;
	}

	public LocalDateTime getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(LocalDateTime createDateTime) {
		this.createDateTime = createDateTime;
	}

	public LocalDateTime getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(LocalDateTime updateDateTime) {
		this.updateDateTime = updateDateTime;
	}

	public ItemDetails getItemDetail() {
		return itemDetail;
	}

	public void setItemDetail(ItemDetails itemDetail) {
		this.itemDetail = itemDetail;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", customerId=" + customerId + ", status=" + status + ", restaurantId="
				+ restaurantId + ", createDateTime=" + createDateTime + ", updateDateTime=" + updateDateTime
				+ ", itemDetail=" + itemDetail + "]";
	}

	
	

}
