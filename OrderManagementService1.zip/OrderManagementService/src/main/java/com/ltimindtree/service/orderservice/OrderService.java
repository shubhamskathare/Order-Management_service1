package com.ltimindtree.service.orderservice;

import java.util.List;

import com.ltimindtree.entity.Order;
import com.ltimindtree.exception.OrderNotFoundException;

public interface OrderService {
	
	
	public List<Order> viewOrder() throws OrderNotFoundException;
	public Order viewOrderById(long id) throws OrderNotFoundException;
	//public Order createOrders(Order orders);
	public void deleteOrderById(long id);
	public Order updateOrder(Order order, long id) throws OrderNotFoundException;
	public double getOrderAmountByOrderId( long id) throws OrderNotFoundException;
	public Order placeOrder(Order orderss);
	

}
