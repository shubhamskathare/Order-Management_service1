package com.ltimindtree.service.orderservice.impl;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ltimindtree.entity.Order;
import com.ltimindtree.exception.OrderNotFoundException;
import com.ltimindtree.repository.OrderRepository;
import com.ltimindtree.service.orderservice.OrderService;


@Service
public  class OrderServiceImpl implements OrderService{
	
	@Autowired
	private OrderRepository orderRepository;
	
	@Override
	public Order placeOrder(Order orderss) {
		
		try {
			return orderRepository.save(orderss);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
		

	@Override
	public List<Order> viewOrder() throws OrderNotFoundException {
		// TODO Auto-generated method stub
		return orderRepository.findAll();
	}

	@Override
	public Order viewOrderById(long id) throws OrderNotFoundException {
		// TODO Auto-generated method stub
		return orderRepository.findById(id).orElseThrow(()-> new OrderNotFoundException("Order", "Id", id));
	}

	/*
	 * @Override public Order createOrders(Order orders) { // TODO Auto-generated
	 * method stub return orderRepository.save(orders); }
	 */
	@Override
	public void deleteOrderById(long id) {
		// TODO Auto-generated method stub
		orderRepository.deleteById(id);
		
	}

	@Override
	public Order updateOrder(Order order, long id) throws OrderNotFoundException {
		// TODO Auto-generated method stub
		Order existingOrder=orderRepository.findById(id).orElseThrow(()-> new OrderNotFoundException("Order", "Id", id));
		existingOrder.setRestaurantId(order.getRestaurantId());
		existingOrder.setCustomerId(order.getCustomerId());
		existingOrder.setCreateDateTime(order.getCreateDateTime());
		existingOrder.setUpdateDateTime(order.getUpdateDateTime());
		existingOrder.setItemDetail(order.getItemDetail());
		existingOrder.setStatus(order.getStatus());
		
		return orderRepository.save(existingOrder);
	}

	@Override
	public double getOrderAmountByOrderId(long id) throws OrderNotFoundException {
		List<Order> itemsOrdered= orderRepository.findOrderById(id);
		if(itemsOrdered !=null) {
		
		double totalAmount=0;
			for(Order item: itemsOrdered ) {
				 totalAmount +=  (item.getItemDetail().getPrice() * item.getItemDetail().getQuantity());
				
			}
			return totalAmount;
		}
	
	else {
		return 0;
	}
	
	}

	
	
}
